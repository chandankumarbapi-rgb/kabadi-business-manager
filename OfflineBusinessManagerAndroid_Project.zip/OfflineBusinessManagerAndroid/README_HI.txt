Offline Business Manager — Android project

इस प्रोजेक्ट में आपका ऑफलाइन कबाड़-खरीद बिलिंग ऐप Android WebView के अंदर पैक किया गया है।
ऐप में इंटरनेट permission नहीं है और HTML/JavaScript asset ऐप के साथ शामिल है।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस फ़ोल्डर को Open करें।
3. Gradle sync पूरा होने दें (पहली बार Android Gradle Plugin/SDK डाउनलोड करने के लिए इंटरनेट लग सकता है)।
4. Build > Build APK(s) चुनें।
5. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में बनेगा।

ध्यान:
- यह ZIP Android Studio project/source है, तैयार APK नहीं।
- इस वातावरण में Android SDK/Gradle build चलाकर signed APK compile नहीं किया गया है।
- डेटा ऐप के WebView local storage में रखा जाता है; app data clear/uninstall करने से डेटा हट सकता है।
- ऐप चलाने के लिए इंटरनेट/होस्टिंग/सर्वर की जरूरत नहीं। बैकअप सुविधा ऐप में है।
